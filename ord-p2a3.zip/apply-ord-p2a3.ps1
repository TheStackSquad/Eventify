# apply-ord-p2a3.ps1 : ORD patch P2a3 (F207, idempotent order initialization). Run from the repo root.
# Edits existing Go files; the new files (migration 000016, idempotency.go, order_idempotency.go,
# order_repo_idempotency.go) are already in place from the zip.
# Every edit must match exactly once; otherwise NOTHING is written (git is the undo, so use a branch).
param([string]$Root = (Get-Location).Path)
$ErrorActionPreference = 'Stop'
$nl = "`n"; $t = "`t"

$plan = @(
    @{ File = 'backend/pkg/models/order.go'; Steps = @(
        @{ Name = 'Order: idempotency columns and Replayed flag'
           Already = 'IdempotencyKey'
           Find = '(AppProfit\s+int64\s+`json:"appProfit" db:"app_profit"`)'
           Replace = ('${1}' + $nl + $t + 'IdempotencyKey    sql.NullString `json:"-" db:"idempotency_key"`' + $nl + $t + 'IdempotencyHash   sql.NullString `json:"-" db:"idempotency_hash"`' + $nl + $t + 'AuthorizationURL  sql.NullString `json:"-" db:"authorization_url"`' + $nl + $t + 'Replayed          bool           `json:"-" db:"-"`') }
    ) },
    @{ File = 'backend/pkg/models/order_initialization.go'; Steps = @(
        @{ Name = 'request: IdempotencyKey (set from the header)'
           Already = 'IdempotencyKey'
           Find = '(UserID\s+\*uuid\.UUID\s+`json:"userId,omitempty"`)'
           Replace = ('${1}' + $nl + $t + 'IdempotencyKey string `json:"-"` // set from the Idempotency-Key header, never from the body') }
    ) },
    @{ File = 'backend/pkg/repository/order/order_repo.go'; Steps = @(
        @{ Name = 'interface: FindLiveByIdempotencyKey, SetAuthorizationURL'
           Already = 'FindLiveByIdempotencyKey'
           Find = '(\n[ \t]*LoadOrderRelations\(ctx context\.Context, order \*models\.Order\) error)'
           Replace = ('${1}' + $nl + $t + 'FindLiveByIdempotencyKey(ctx context.Context, userID *uuid.UUID, guestID, key string) (*models.Order, error)' + $nl + $t + 'SetAuthorizationURL(ctx context.Context, orderID uuid.UUID, url string) error') },
        @{ Name = 'SavePendingOrderTx: insert the idempotency columns'
           Already = 'webhook_attempts, idempotency_key'
           Find = 'processed_by, webhook_attempts,(\s*)created_at, updated_at(\s*)\) VALUES \('
           Replace = 'processed_by, webhook_attempts, idempotency_key, idempotency_hash,${1}created_at, updated_at${2}) VALUES (' },
        @{ Name = 'SavePendingOrderTx: insert the idempotency values'
           Already = ':idempotency_key'
           Find = ':processed_by, :webhook_attempts,(\s*):created_at, :updated_at(\s*)\)'
           Replace = ':processed_by, :webhook_attempts, :idempotency_key, :idempotency_hash,${1}:created_at, :updated_at${2})' }
    ) },
    @{ File = 'backend/pkg/services/order/order_services.go'; Steps = @(
        @{ Name = 'replay an existing order before pricing'
           Already = 'replayIdempotent(ctx, req'
           Find = '(\n[ \t]*// 2\. AUTHORITATIVE PRICING CALCULATION)'
           Replace = ($nl + $t + '// Idempotency (F207): a retry with the same key and the same request gets the original order back.' + $nl + $t + 'if req.IdempotencyKey != "" {' + $nl + $t + $t + 'if existing, existingURL, found, lerr := s.replayIdempotent(ctx, req, userID, guestID); lerr != nil || found {' + $nl + $t + $t + $t + 'return existing, existingURL, lerr' + $nl + $t + $t + '}' + $nl + $t + '}' + $nl + '${1}') },
        @{ Name = 'store the key and request hash on the new order'
           Already = 'pendingOrder.IdempotencyKey ='
           Find = '(pendingOrder\.UpdatedAt = now\n)'
           Replace = ('${1}' + $t + 'if req.IdempotencyKey != "" {' + $nl + $t + $t + 'pendingOrder.IdempotencyKey = sql.NullString{String: req.IdempotencyKey, Valid: true}' + $nl + $t + $t + 'pendingOrder.IdempotencyHash = sql.NullString{String: req.IdempotencyHash(), Valid: true}' + $nl + $t + '}' + $nl) },
        @{ Name = 'a concurrent request with the same key won the race'
           Already = 'isIdempotencyConflict(err)'
           Find = '(if err != nil \{\s*\n\s*return nil, "", err\s*\n\s*\})(\s*\n\s*// 5\. EXTERNAL HANDSHAKE)'
           Replace = ('if err != nil {' + $nl + $t + $t + 'if req.IdempotencyKey != "" && isIdempotencyConflict(err) {' + $nl + $t + $t + $t + '// Another request with the same key inserted its order first: return it, or ask the client to retry.' + $nl + $t + $t + $t + 'if existing, existingURL, found, lerr := s.replayIdempotent(ctx, req, userID, guestID); lerr != nil || found {' + $nl + $t + $t + $t + $t + 'return existing, existingURL, lerr' + $nl + $t + $t + $t + '}' + $nl + $t + $t + $t + 'return nil, "", ErrIdempotencyInProgress' + $nl + $t + $t + '}' + $nl + $t + $t + 'return nil, "", err' + $nl + $t + '}' + '${2}') },
        @{ Name = 'remember the payment link for replays'
           Already = 'SetAuthorizationURL('
           Find = '\n[ \t]*return pendingOrder, authURL, nil'
           Replace = ($nl + $t + '// Remember the payment link so a retry with the same Idempotency-Key can return it (F207).' + $nl + $t + 'if req.IdempotencyKey != "" {' + $nl + $t + $t + 'if uerr := s.OrderRepo.SetAuthorizationURL(ctx, pendingOrder.ID, authURL); uerr != nil {' + $nl + $t + $t + $t + 'log.Error().Err(uerr).Str("ref", pendingOrder.Reference).Msg("Could not store the payment link; a retry with the same Idempotency-Key will be asked to wait")' + $nl + $t + $t + '}' + $nl + $t + '}' + $nl + $nl + $t + 'return pendingOrder, authURL, nil') }
    ) },
    @{ File = 'backend/pkg/handlers/order/order.go'; Steps = @(
        @{ Name = 'import strings'
           Already = '"strings"'
           Find = '(\t"errors"\n)'
           Replace = ('${1}' + $t + '"strings"' + $nl) },
        @{ Name = 'read and validate the Idempotency-Key header'
           Already = 'INVALID_IDEMPOTENCY_KEY'
           Find = '(\n[ \t]*// 1\. Extract Identity consistently)'
           Replace = ($nl + $t + '// Optional Idempotency-Key header: a retry with the same key returns the original order instead of reserving stock again (F207).' + $nl + $t + 'if key := strings.TrimSpace(c.GetHeader("Idempotency-Key")); key != "" {' + $nl + $t + $t + 'if !models.ValidIdempotencyKey(key) {' + $nl + $t + $t + $t + 'c.JSON(http.StatusBadRequest, gin.H{"status": "error", "code": "INVALID_IDEMPOTENCY_KEY", "message": "Idempotency-Key must be 8 to 128 characters: letters, digits, - _ . or :"})' + $nl + $t + $t + $t + 'return' + $nl + $t + $t + '}' + $nl + $t + $t + 'req.IdempotencyKey = key' + $nl + $t + '}' + $nl + '${1}') },
        @{ Name = 'map the idempotency errors'
           Already = 'REQUEST_IN_PROGRESS'
           Find = '(case errors\.Is\(err, serviceorder\.ErrInvalidOrder\):\s*\n\s*status, code, msg = http\.StatusBadRequest, "INVALID_ORDER", err\.Error\(\))'
           Replace = ('${1}' + $nl + $t + $t + 'case errors.Is(err, serviceorder.ErrIdempotencyInProgress):' + $nl + $t + $t + $t + 'c.Header("Retry-After", "1")' + $nl + $t + $t + $t + 'status, code, msg = http.StatusConflict, "REQUEST_IN_PROGRESS", "This request is still being processed. Please retry in a moment."' + $nl + $t + $t + 'case errors.Is(err, serviceorder.ErrIdempotencyKeyReused):' + $nl + $t + $t + $t + 'status, code, msg = http.StatusUnprocessableEntity, "IDEMPOTENCY_KEY_REUSED", "This Idempotency-Key was already used for a different request."') },
        @{ Name = 'a replay answers 200 with Idempotent-Replay: true'
           Already = 'replyStatus'
           Find = '(//\s*3\. Return the payload for the frontend to redirect\s*\n\s*)c\.JSON\(http\.StatusCreated, gin\.H\{'
           Replace = ('${1}replyStatus := http.StatusCreated' + $nl + $t + 'if order.Replayed {' + $nl + $t + $t + 'c.Header("Idempotent-Replay", "true")' + $nl + $t + $t + 'replyStatus = http.StatusOK' + $nl + $t + '}' + $nl + $t + 'c.JSON(replyStatus, gin.H{') }
    ) },
    @{ File = 'backend/pkg/routes/router.go'; Steps = @(
        @{ Name = 'CORS: allow the Idempotency-Key request header (WIRING:ord)'
           Already = '"Idempotency-Key"'
           Find = '(AllowHeaders:\s*\[\]string\{[^}]*"X-CSRF-Token")\}(,?)'
           Replace = '${1}, "Idempotency-Key"}${2} // WIRING:ord' },
        @{ Name = 'CORS: let the browser read Retry-After and Idempotent-Replay (WIRING:ord)'
           Already = 'Idempotent-Replay'
           Find = '(ExposeHeaders:\s*\[\]string\{[^}]*"X-CSRF-Token")\}(,?)'
           Replace = '${1}, "Retry-After", "Idempotent-Replay"}${2} // WIRING:ord' }
    ) }
)

$staged = @(); $problems = @()
foreach ($f in $plan) {
    $path = Join-Path $Root $f.File
    if (-not (Test-Path -LiteralPath $path)) { $problems += "missing file: $($f.File)"; continue }
    $raw = [IO.File]::ReadAllText($path)
    $crlf = $raw.Contains("`r`n")
    $text = $raw -replace "`r`n", "`n"
    foreach ($s in $f.Steps) {
        if ($text.Contains($s.Already)) { Write-Host "  skip (already applied): $($f.File): $($s.Name)" -ForegroundColor DarkGray; continue }
        $m = [regex]::Matches($text, $s.Find)
        if ($m.Count -ne 1) { $problems += "$($f.File): '$($s.Name)' matched $($m.Count) time(s), expected 1"; continue }
        $re = [regex]::new($s.Find)
        $text = $re.Replace($text, $s.Replace, 1)
        Write-Host "  edit: $($f.File): $($s.Name)" -ForegroundColor Green
    }
    if ($crlf) { $text = $text -replace "`n", "`r`n" }
    $staged += [pscustomobject]@{ Path = $path; Text = $text; Changed = ($text -ne $raw) }
}
if ($problems.Count) {
    Write-Host "`nNothing was written. Problems:" -ForegroundColor Red
    $problems | ForEach-Object { Write-Host "  $_" -ForegroundColor Red }
    Write-Host 'Send me the named file(s) as they are now and I will re-anchor the edit.' -ForegroundColor Yellow
    exit 2
}
foreach ($s in $staged) { if ($s.Changed) { [IO.File]::WriteAllText($s.Path, $s.Text, (New-Object Text.UTF8Encoding($false))) } }
Write-Host "`nDone. Now, from backend\:  go build ./... ; go vet ./... ; go test ./pkg/models/..." -ForegroundColor Cyan
